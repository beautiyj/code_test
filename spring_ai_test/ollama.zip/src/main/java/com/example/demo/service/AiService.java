package com.example.demo.service;

import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.ollama.api.OllamaChatOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class AiService {

	@Autowired
	private ChatModel chatModel;

	// 사용자 질문에 대해 답변을 생성하는 메서드
	public String generateText(String question) {

		//1. 시스템 메세지 생성 
		// 시스템 메세지는 모델에게 대화의 맥락을 제공하고, 모델이 어떻게 응답해야 하는지 지시하는 역할
		SystemMessage systemMessage = SystemMessage.builder()
				.text("사용자 질문에 대해 한국어로 답변을 해야 합니다.").build();

		//2. 사용자 메세지 생성
		// 사용자 메세지는 실제로 사용자가 모델에게 전달하는 질문이나 요청을 의미함
		UserMessage userMessage = UserMessage.builder()
				.text(question).build();

		//3. 대화 옵션 설정
		// ChatOptions는 모델의 동작을 제어하는 다양한 설정을 포함함
		OllamaChatOptions chatOptions = OllamaChatOptions.builder()
//				.model("llama3.1") 		// 사용할 모델 설정 (application.properties의 설정을 오버라이드할 때 사용)
				.temperature(0.3) 		// 응답의 창의성 설정 (0.0 ~ 1.0)
				.maxTokens(100) 		// 최대 토큰 수 설정
				.build();

		//4. 프롬프트 생성
		// Prompt는 시스템 메세지, 사용자 메세지, 대화 옵션을 포함하여 모델에게 전달할 전체 입력을 구성함
		Prompt prompt = Prompt.builder()
				.messages(systemMessage, userMessage)
				.chatOptions(chatOptions).build();

		//5. LLM에게 요청하고 응답받기
		// chatModel.call() 메서드를 사용하여 프롬프트를 전달하고, 모델의 응답을 ChatResponse 객체로 받음
		ChatResponse chatResponse = chatModel.call(prompt);
		
		//6. 모델의 응답에서 실제 답변 추출
		AssistantMessage assistantMessage = chatResponse.getResult().getOutput();
		// AssistantMessage는 모델이 생성한 답변을 포함하며, getText() 메서드를 통해 실제 텍스트를 얻을 수 있음
		String answer = assistantMessage.getText();

		return answer;
	}

}
