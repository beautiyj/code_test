package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.AiService;

@RestController
@RequestMapping("/ai")
public class AiController {
	
	@Autowired
	private AiService aiService;
	
	// AI 챗봇과의 대화를 처리하는 메서드
	@PostMapping(value="/chat")
//				,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, // 폼 데이터로 요청을 받을 때 사용
//			     produces = MediaType.TEXT_PLAIN_VALUE)  				 // 클라이언트에게 JSON 형식으로 응답을 보낼 때 사용
	public String chat(@RequestParam("question") String question) {
		System.out.println("chatting...");
		System.out.println("question : " + question);
		
		// AI 서비스에 질문을 전달하고 답변을 받음
		String answerTest = aiService.generateText(question);		
		System.out.println("answerTest : " + answerTest);		
		
		return answerTest;
	}

}
