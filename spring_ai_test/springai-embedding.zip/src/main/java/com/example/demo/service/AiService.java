package com.example.demo.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.ai.document.Document;
import org.springframework.ai.embedding.Embedding;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.ai.embedding.EmbeddingResponseMetadata;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AiService {
 
  @Autowired
  private EmbeddingModel embeddingModel;  //  

  @Autowired
  private VectorStore vectorStore;

  //1. 임베딩 모델을 이용하여 텍스트를 벡터로 변환
  public void textEmbedding(String question) {
    

  }

    
  //2. Document를 벡터 저장소에 추가
  public void addDocument() {
    

  }


  //3. Document를 벡터 저장소에서 검색
  public List<Document> searchDocument1(String question) {
	  
	
	return null;
  }


  //4. Document를 벡터 저장소에서 검색 (필터링 적용)
  public List<Document> searchDocument2(String question) {
    

    return null;
  }


//4. Document를 벡터 저장소에서 검색 (필터링 적용)
//   public List<Document> searchDocument2(String question) {
//     FilterExpressionBuilder feb = new FilterExpressionBuilder();
//
//     List<Document> documents = vectorStore.similaritySearch(
//         SearchRequest.builder()
//             .query(question)
//             .topK(1)
//             .similarityThreshold(0.3)
//             .filterExpression(feb
//                 .and(
//                     feb.eq("source", "헌법"),
//                     feb.gte("year", 1987))
//                 .build())
//             .build());
//     return documents;
//   }

   
  //5. Document를 벡터 저장소에서 삭제
  public void deleteDocument() {
   

  }
  
}
