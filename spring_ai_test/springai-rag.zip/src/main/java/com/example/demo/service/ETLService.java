package com.example.demo.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.document.Document;
import org.springframework.ai.document.DocumentReader;
import org.springframework.ai.document.DocumentTransformer;
import org.springframework.ai.model.transformer.KeywordMetadataEnricher;
import org.springframework.ai.reader.JsonMetadataGenerator;
import org.springframework.ai.reader.JsonReader;
import org.springframework.ai.reader.TextReader;
import org.springframework.ai.reader.jsoup.JsoupDocumentReader;
import org.springframework.ai.reader.jsoup.config.JsoupDocumentReaderConfig;
import org.springframework.ai.reader.pdf.PagePdfDocumentReader;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ETLService {
  
  private ChatModel chatModel;
  private VectorStore vectorStore;

  // 생성자
  public ETLService(ChatModel chatModel, VectorStore vectorStore) {
    this.chatModel = chatModel;
    this.vectorStore = vectorStore;
  }

  //1. txt, pdf, word ETL 처리
  public String etlFromFile(String title, String author,
      MultipartFile attach) throws IOException {

    // 추출하기 : extractFromFile() 함수 호출
    

    // 메타데이터에 공통 정보 추가하기
    

    // Document로 변환하기 : transform() 함수 호출
   

    // 벡터 저장소에 저장하기
   

    return "올린 문서를 추출-변환-적재 완료 했습니다.";
  }
  

  // 업로드된 첨부 파일로부터 텍스트를 추출하는 메소드 
  private List<Document> extractFromFile(MultipartFile attach) throws IOException {
    // 바이트 배열을 Resource로 생성
    Resource resource = new ByteArrayResource(attach.getBytes());

    List<Document> documents = null;
    if (attach.getContentType().equals("text/plain")) {
      // Text(.txt) 파일일 경우
      DocumentReader reader = new TextReader(resource);
      documents = reader.read();
    } else if (attach.getContentType().equals("application/pdf")) {
      // PDF(.pdf) 파일일 경우
      DocumentReader reader = new PagePdfDocumentReader(resource);
      documents = reader.read();
    } else if (attach.getContentType().contains("wordprocessingml")) {
      // Word(.doc, .docx) 파일일 경우
      DocumentReader reader = new TikaDocumentReader(resource);
      documents = reader.read();
    }

    return documents;
  }

  
  // 작은 크기로 분할하고 키워드 메타데이터를 추가하는 메소드
  private List<Document> transform(List<Document> documents) {
    List<Document> transformedDocuments = null;

    // 작게 분할하기
    TokenTextSplitter tokenTextSplitter = new TokenTextSplitter();
    transformedDocuments = tokenTextSplitter.apply(documents);

    // 메타데이터에 키워드 추가하기
    KeywordMetadataEnricher keywordMetadataEnricher = 
        new KeywordMetadataEnricher(chatModel, 5);
    transformedDocuments = keywordMetadataEnricher.apply(transformedDocuments);

    return transformedDocuments;
  }

  //-----------------------------------------------------------------------------------  
  
  //2. html ETL 처리
  public String etlFromHtml(String title, String author, String url) throws Exception {
    // URL로부터 Resource 얻기
   

    // E: 추출하기
    

    // T: 변환하기
    

    // L: 적재하기
    

    return "HTML에서 추출-변환-적재 완료 했습니다.";
  }

  
  
  //3. json ETL 처리
  public String etlFromJson(String url) throws Exception {
    // URL로부터 Resource 얻기
   

    // E: 추출하기
    
    
    

    // T: 변환하기
    


    // L: 적재하기
    


    return "JSON에서 추출-변환-적재 완료 했습니다.";
  }
  
}
