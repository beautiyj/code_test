package com.example.demo.recommendmovie;

import java.util.List;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RecommendMovieTools {

  //1. 사용자가 관람한 영화 목록을 제공하는 도구(tool) 설정	
  @Tool(description = "사용자가 관람한 영화 목록을 제공합니다.")
  public List<String> getMovieListByUserId(
    @ToolParam(description = "사용자 ID", required = true) String userId) {
    

    return null;
  } 

  
  //2. 주어진 쟝르의 추천 영화 목록을 제공하는 도구(tool) 설정
  // returnDirect = true 이면 직접 반환하도록 설정
  // returnDirect = false 이면 LLM이 JSON으로 반환하도록 설정
  
  @Tool(description = "주어진 쟝르의 추천 영화 목록을 제공합니다.", returnDirect = true)
  public List<String> recommendMovie(
    @ToolParam(description = "쟝르", required = true) String genre) {
    

    return null;
  }

}
