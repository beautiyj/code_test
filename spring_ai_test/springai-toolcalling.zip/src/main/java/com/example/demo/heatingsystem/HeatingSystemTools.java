package com.example.demo.heatingsystem;

import java.util.Random;

import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class HeatingSystemTools {
	
  // HeatingSystemTools 클래스는 난방 시스템을 제어하는 도구(tool)를 정의하는 클래스
  // 1. 현재 온도를 23도 유지해줘  요청에 따라서 
  //    현재 온도가 23 미만이면 난방 시스템을 가동하는 도구(startHeatingSystem)가 호출되고,
  //    현재 온도가 23 이상이면 난방 시스템을 중지하는 도구(stopHeatingSystem)가 호출된다.

  //1. 난방 시스템을 가동하는 도구(tool) 설정  	
  @Tool(description = 
    """
      타겟 온도까지 난방 시스템을 가동합니다.
      난방 시스템 가동이 성공되었을 경우 success를 반환합니다.
      난방 시스템 가동이 실패되었을 경우 failure를 반환합니다.
    """
  )
  public String startHeatingSystem(
    @ToolParam(description = "타겟 온도", required = true) int targetTemperature,
    ToolContext toolContext) {  // ToolContext를 통해 난방 시스템을 가동할 권한을 확인
    



      return "";
    }
  } 

  
  //2. 난방 시스템을 중지하는 도구(tool) 설정
  @Tool(description = 
    """
    난방 시스템을 중지합니다.
    난방 시스템 중지가 성공되었을 경우 success를 반환합니다.
    난방 시스템 중지가 실패되었을 경우 failure를 반환합니다.
    """
  )
  public String stopHeatingSystem(ToolContext toolContext) { // ToolContext를 통해 난방 시스템을 중지할 권한을 확인
    



	return "";
  } 

  
  //3. 현재 온도를 구해오는 도구(tool) 설정
  @Tool(description = "현재 온도를 제공합니다.")
  public int getTemperature() {
   


    return 25;
  }   

}
