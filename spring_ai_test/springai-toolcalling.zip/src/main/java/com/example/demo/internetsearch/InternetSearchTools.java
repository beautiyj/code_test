package com.example.demo.internetsearch;

import java.time.LocalDateTime;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class InternetSearchTools {
  
  
	private String searchEndpoint;		// SerpApi 엔드포인트
  
	private String apiKey;				// SerpApi API 키
  
	private WebClient webClient;		// WebClient 인스턴스
  
	private ObjectMapper objectMapper = new ObjectMapper(); // JSON 파싱을 위한 ObjectMapper

  
	
	// 생성자 
  
	public InternetSearchTools(
      
		@Value("${serpapi.endpoint}") String searchEndpoint,      
      
		@Value("${serpapi.apiKey}") String apiKey,
      
		WebClient.Builder webClientBuilder
  ) {
    
		this.searchEndpoint = searchEndpoint;
    
		this.apiKey = apiKey;							 // SerpApi API 키 설정
    
		this.webClient = webClientBuilder
        
			.baseUrl(searchEndpoint)					 // SerpApi 엔드포인트 설정
        
			.defaultHeader("Accept", "application/json") // 기본 헤더 설정
        
			.build();									 // WebClient 인스턴스 생성
  
	}


  //1. 인터넷 검색을 수행하는 도구(tool)	
  //   검색 결과를 제목, 링크, 요약으로 문자열로 반환
  @Tool(description = "인터넷 검색을 합니다. 제목, 링크, 요약을 문자열로 반환합니다.")
  
  public String search(String query) {
    
	  


     return "";
 }

  
  //2. 웹 페이지의 본문 텍스트를 반환하는 도구(tool)
  @Tool(description = "웹 페이지의 본문 텍스트를 반환합니다.")
  public String fetch(String url) {
    


	return "";
  }
  
  
  //3. 현재 날짜와 시간 정보를 반환하는 도구(tool)
  @Tool(description = "현재 날짜와 시간 정보를 제공합니다.")
  public String getCurrentDateTime() {
    

    return "";
  }  

}
