package com.example.demo.datetime;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DateTimeTools {
	
  //1. 현재 시간을 구해오는 도구(tool) 설정    	
  @Tool(description = "현재 날짜와 시간 정보를 제공합니다.")
  public String getCurrentDateTime() {
    


    return "";
  }

  //2. 알람을 설정하는 도구(tool) 설정	
  @Tool(description = "지정된 시간에 알람을 설정합니다.")  
  public void setAlarm(
      @ToolParam(description = "ISO-8601 형식의 시간", required = true)  // ISO-8601 형식의 시간
      String time) {
    


  } 
}
