package com.example.demo.service;

import java.util.Map;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AiServiceZeroShotPrompt {
  
  private ChatClient chatClient;
  
  // 영화 리뷰를 분류하기 위한 프롬프트 템플릿 정의
  

  // 생성자
  

  // 영화 리뷰를 입력받아 감정을 분류하는 메서드 
  

}
