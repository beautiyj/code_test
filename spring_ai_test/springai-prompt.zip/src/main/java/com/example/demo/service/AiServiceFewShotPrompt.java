package com.example.demo.service;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AiServiceFewShotPrompt {
  
  private ChatClient chatClient;

  // 생성자 
  


  // 고객 주문을 입력받아 JSON 형식으로 변환하는 메서드
  public String fewShotPrompt(String order) {
    // 프롬프트 생성
    

    // LLM으로 요청하고 응답을 받음
    
  }
}
