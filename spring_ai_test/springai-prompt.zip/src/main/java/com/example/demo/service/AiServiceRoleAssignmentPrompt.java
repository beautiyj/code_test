package com.example.demo.service;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class AiServiceRoleAssignmentPrompt {
 
  private ChatClient chatClient;

  // 생성자
  

  // 시스템 메시지를 활용해서 역할 부여하기 
  public Flux<String> roleAssignment(String requirements) {
    


  }
}
