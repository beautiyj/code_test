package com.example.demo.service;

import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.ai.audio.transcription.AudioTranscriptionPrompt;
import org.springframework.ai.audio.transcription.AudioTranscriptionResponse;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.content.Media;
import org.springframework.ai.openai.OpenAiAudioSpeechModel;
import org.springframework.ai.openai.OpenAiAudioSpeechOptions;
import org.springframework.ai.openai.OpenAiAudioTranscriptionModel;
import org.springframework.ai.openai.OpenAiAudioTranscriptionOptions;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.ai.openai.api.OpenAiApi;
import org.springframework.ai.openai.api.OpenAiApi.ChatCompletionRequest;
import org.springframework.ai.openai.api.OpenAiApi.ChatCompletionRequest.AudioParameters;
import org.springframework.ai.openai.api.OpenAiAudioApi.SpeechRequest;
import org.springframework.ai.openai.api.OpenAiAudioApi.SpeechRequest.AudioResponseFormat;
import org.springframework.ai.audio.tts.TextToSpeechPrompt;
import org.springframework.ai.audio.tts.TextToSpeechResponse;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeType;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class AiService {
  
  private ChatClient chatClient;
  private OpenAiAudioTranscriptionModel openAiAudioTranscriptionModel;  // STT 모델
  private OpenAiAudioSpeechModel openAiAudioSpeechModel;                // TTS 모델

  // 생성자 주입을 통해 필요한 의존성을 주입받음
  public AiService(ChatClient.Builder chatClientBuilder,
		  		   OpenAiAudioTranscriptionModel openAiAudioTranscriptionModel,
		  		   OpenAiAudioSpeechModel openAiAudioSpeechModel) {
    chatClient = chatClientBuilder.build();
    this.openAiAudioTranscriptionModel = openAiAudioTranscriptionModel;
    this.openAiAudioSpeechModel = openAiAudioSpeechModel;
  }

  
  //1. STT (Speech-to-Text) 기능 구현
  public String stt(String fileName, byte[] bytes) {
   
	// 음성 데이터(byte[])를 ByteArrayResource로 생성하고, getFilename() 메서드를 오버라이드하여 파일 이름을 제공
	

    // 모델 옵션 설정
    

    // 프롬프트 생성

    
    // 모델을 호출하고 응답받기
   
  }

  
  
  //2. TTS (Text-to-Speech) 기능 구현 (기본 목소리: ALLOY - 중성적)
  public byte[] tts(String text) {
    return tts(text, SpeechRequest.Voice.ALLOY);
  }

  // 목소리(성별 톤)를 선택할 수 있는 TTS 기능
  // 남성적인 목소리: ECHO, ONYX, ASH, BALLAD, VERSE
  // 여성적인 목소리: NOVA, SHIMMER, CORAL, SAGE
  // 중성적인 목소리: ALLOY, FABLE
  public byte[] tts(String text, SpeechRequest.Voice voice) {
    // 모델 옵션 설정
    

    // 프롬프트 생성
    

    // 모델을 호출하고 응답받기
   
  }    

  
  //3. 텍스트도 같이 출력되는 음성 대화
  public Map<String, String> chatText(String question) {
    // LLM로 요청하고, 텍스트 응답 얻기
    String textAnswer = chatClient.prompt()          
        .system("50자 이내로 한국어로 답변해주세요.")        
        .user(question) 							 
        .call()
        .content();

    // TTS 모델로 요청하고 응답으로 받은 음성 데이터를 base64 문자열로 변환
    byte[] audio = tts(textAnswer);
    String base64Audio = Base64.getEncoder().encodeToString(audio);

    // 텍스트 답변과 음성 답변을 Map에 저장
    Map<String, String> response = new HashMap<>();
    response.put("text", textAnswer);
    response.put("audio", base64Audio);

    return response;
  }
  
  // 비동기 TTS 기능 구현
  public Flux<byte[]> ttsFlux(String text) {
    // 모델 옵션 설정
    OpenAiAudioSpeechOptions options = OpenAiAudioSpeechOptions.builder()
        .model("gpt-4o-mini-tts")
        .voice(SpeechRequest.Voice.ALLOY)
        .responseFormat(AudioResponseFormat.MP3)
        .speed(1.0)
        .build();

    // 프롬프트 생성
    TextToSpeechPrompt prompt = new TextToSpeechPrompt(text, options);

    // 모델로 요청하고 응답받기
    Flux<TextToSpeechResponse> response = openAiAudioSpeechModel.stream(prompt);
    Flux<byte[]> flux = response.map(speechResponse -> speechResponse.getResult().getOutput());
    return flux;
  }   
  
  
  //4. 순수 음성 대화 구현 (방법1)
  public Flux<byte[]> chatVoiceSttLlmTts(byte[] audioBytes) {
    // STT를 이용해서 음성 질문을 텍스트 질문으로 변환
    String textQuestion = stt("speech.mp3", audioBytes);

    // 텍스트 질문으로 LLM에 요청하고, 텍스트 응답 얻기
    String textAnswer = chatClient.prompt()
        .system("50자 이내로 답변해주세요.")
        .user(textQuestion)
        .call()
        .content();

    // TTS를 이용해서 비동기 음성 데이터 얻기
    Flux<byte[]> flux = ttsFlux(textAnswer);
    return flux;
  }   

  
  //5. 순수 음성 대화 구현 (방법2)
  public byte[] chatVoiceOneModel(byte[] audioBytes, String mimeType) throws Exception {
    // 음성 데이터를 Resource로 생성
    Resource resource = new ByteArrayResource(audioBytes);

    // 사용자 메시지 생성
    UserMessage userMessage = UserMessage.builder()
        // 빈문자열이라도 제공해야함
        .text("제공되는 음성에 맞는 자연스러운 대화로 이어주세요.")
        .media(new Media(MimeType.valueOf(mimeType), resource))
        .build();

    // 모델 옵션 설정
    ChatOptions chatOptions = OpenAiChatOptions.builder()
        .model(OpenAiApi.ChatModel.GPT_4_O_MINI_AUDIO_PREVIEW)  // gpt-4o-mini-audio 모델 사용
        .outputModalities(List.of("text", "audio"))              
        .outputAudio(new AudioParameters(
            ChatCompletionRequest.AudioParameters.Voice.ALLOY,
            ChatCompletionRequest.AudioParameters.AudioResponseFormat.MP3))
        .build();

    // gpt-4o-mini-audio 모델은 스트림을 지원하지 않기 때문에 동기 방식 사용
    // 모델로 요청하고 응답 받기
    ChatResponse response = chatClient.prompt()
        .system("50자 이내로 답변해주세요.")
        .messages(userMessage)
        .options(chatOptions)
        .call()
        .chatResponse();
    
    // AI 메시지 얻기
    AssistantMessage assistantMessage = response.getResult().getOutput();
    
    // 텍스트 답변 얻기
    String textAnswer = assistantMessage.getText();
    log.info("텍스트 응답: {}", textAnswer);

    // 오디오 답변 얻기
    byte[] audioAnswer = assistantMessage.getMedia().get(0).getDataAsByteArray();

    return audioAnswer;
  }  
  
}
