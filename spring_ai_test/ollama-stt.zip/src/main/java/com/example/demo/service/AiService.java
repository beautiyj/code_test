package com.example.demo.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class AiService {

  private final ChatClient chatClient;

  public AiService(ChatClient.Builder chatClientBuilder) {
    this.chatClient = chatClientBuilder.build();
  }

  public Map<String, String> chatText(String question) {
    String safeQuestion = (question == null || question.isBlank()) ? "안녕하세요" : question;

    String textAnswer = chatClient.prompt()
        .system("당신은 한국어 음성 비서입니다. 3문장 이내로 간결하고 자연스럽게 답변하세요.")
        .user(safeQuestion)
        .call()
        .content();

    Map<String, String> response = new HashMap<>();
    response.put("text", textAnswer);
    return response;
  }
}