package com.example.demo.controller;

import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.AiService;

@RestController
@RequestMapping("/ai")
public class AIController {

  private final AiService aiService;

  public AIController(AiService aiService) {
    this.aiService = aiService;
  }

  @PostMapping(
      value = "/chat-text",
      consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  public Map<String, String> chatText(@RequestParam("question") String question) {
    return aiService.chatText(question);
  }
}