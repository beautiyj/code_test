package com.example.demo.service;

import java.io.IOException;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;

@Service
@Slf4j
public class AiServiceByChatClient {

  

  // 질문에 대한 답변을 문자로 생성하는 메서드
  

  // 질문에 대한 답변을 스트리밍으로 생성하는 메서드
 
}
